/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package homework2;

// import static java.lang.Math.sqrt;

/**
 *
 * @author domenico
 */
public class Complex {
    private double Re;
    private double Imm;
    
    public Complex() {
        this.Re=0.0;
        this.Imm=0.0;
    }

    public Complex(double Re, double Imm) {
        this.Re = Re;
        this.Imm = Imm;
    }
    
    public Complex(Complex C) {
        this.Re = C.Re;
        this.Imm = C.Imm;
    }
    
    public double getRe() {
        return Re;
    }

    public void setRe(double Re) {
        this.Re = Re;
    }

    public double getImm() {
        return Imm;
    }

    public void setImm(double Imm) {
        this.Imm = Imm;
    }
    
    public void stampa(){
        System.out.println("[Re: "+this.Re+", Imm: "+this.Imm+"]");
    }
    public double moduloComplex(){
        return Math.sqrt((this.Re*this.Re)+(this.Imm*this.Imm));
    }
    
    public Complex sommaComplex(Complex OP) {    
        Complex somma = new Complex();
        somma.Re =  this.Re + OP.Re;
        somma.Imm = this.Imm + OP.Imm;
        return somma;
      
    }
    
    public Complex prodottoComplex(Complex OP) {  
        Complex prodotto = new Complex();
        prodotto.Re = this.Re * OP.Re - this.Imm * OP.Imm;
        prodotto.Imm = this.Imm * OP.Re + OP.Imm * this.Re;
        return prodotto;
    }    
}    

