/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package homework2;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author domenico
 */
public class ArrayComplex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int DIM = 3;
        boolean continua = true;
        int scelta;
        Complex[] arrayVettori = new Complex[DIM];
        InsertComplexFromTerminal(arrayVettori, DIM);
        while (continua){
            PrintMenu();
            Scanner input = new Scanner (System.in);
            input.useLocale(Locale.US); 
            scelta = input.nextInt();
            switch(scelta) {
                case 1:
                    System.out.println("L'array di complessi è:");
                    PrintAll(arrayVettori, DIM);
                    break;
                case 2:
                    System.out.println("I moduli dei complessi sono");
                    PrintAllModules(arrayVettori, DIM);
                    break;
                case 3:
                    Complex c;
                    c=new Complex();
                    double Re, Imm;
                    int[] pos = new int[1];
                    System.out.print("Inserisci la parte reale del numero complesso da cercare: ");
                    Re=input.nextDouble();
                    System.out.print("Inserisci la parte immaginario del numero complesso da cercare: ");
                    Imm=input.nextDouble();
                    c.setRe(Re);
                    c.setImm(Imm);
                    if(Search(arrayVettori,DIM, c, pos)){
                        System.out.println("Numero complesso in posizione "+pos[0]);
                    } else {
                        System.out.println("numero complesso non trovato");
                    }
                    break;
                case 4:
                    BubbleSort(arrayVettori, DIM);
                    System.out.println("Vettore ordinato");
                    break;
                case 5:
                    continua=false;
                    break;
            }
        }
    }
    
    public static void InsertComplexFromTerminal(Complex[] array, int DIM){
        Scanner input = new Scanner (System.in); 
        input.useLocale(Locale.US); 
        double real;
        double imaginary;
        for(int i=0; i<DIM; i++){
            System.out.print("Inserire la parte reale del numero complessi di indice "+i+": ");
            real= input.nextDouble();
            System.out.print("Inserire la parte immaginaria del numero complessi di indice "+i+": ");
            imaginary=input.nextDouble();
            array[i]= new Complex(real,imaginary);
        }
    }
    
    public static void PrintAll(Complex[] array, int DIM){
        for(int i=0; i<DIM; i++){
            array[i].stampa();
        }
    }
    
    public static void BubbleSort(Complex[] array, int DIM){
        int i,j;
        Complex pivot;
        for(i=1;i<DIM;i++) {
            for(j=0;j<DIM-i;j++) {
                if(array[j].moduloComplex()>array[j+1].moduloComplex()) {
                    //swap
                    pivot=array[j];
                    array[j]=array[j+1];
                    array[j+1]= pivot;
                }
            }
        }
    }
    
    public static boolean Search(Complex[] array, int DIM, Complex e, int[] pos){
        boolean trovato = false;
        pos[0]= -1;
        int indice=0;
        while(!trovato && indice<DIM){
            if(array[indice].getRe()==e.getRe()&&array[indice].getImm()==e.getImm()){
                trovato=true;
                pos[0]=indice;
            } else {
                indice++;
            }
        }
        return trovato;
    }
    
    public static void PrintAllModules(Complex[] array, int DIM){
        for(int i=0; i<DIM; i++){
            System.out.println("Modulo di num. complesso di pos "+ i+": "+array[i].moduloComplex());
        }
    }
    
    public static void PrintMenu(){
        System.out.println("******* Menu *******");
        System.out.println("1. Stampa array");
        System.out.println("2. Stampa i moduli di tutti i numeri complessi");
        System.out.println("3. Cerca numero complesso");
        System.out.println("4. Ordina array");
        System.out.println("5. Esci");
        System.out.println("********************");
    }
    
}
