/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package homework2;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author domenico
 */
public class TestComplex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //test del costruttore senza parametri e metodi di Get
        Complex c1= new Complex();
        System.out.println("Lo stato del numero complesso vale");
        System.out.println("[Re: "+c1.getRe()+", Imm: "+c1.getImm()+"]");
        //test dei metodi di set
        c1.setRe(0.5);
        c1.setImm(9);
        System.out.println("Lo stato del numero complesso dopo il set vale");
        System.out.println("[Re: "+c1.getRe()+", Imm: "+c1.getImm()+"]");
        
        //test del costruttore di copia
        Complex compCopia = new Complex(c1);
        System.out.println("Lo stato del numero complesso ottenuto per copia vale");
        System.out.println("[Re: "+compCopia.getRe()+", Imm: "+compCopia.getImm()+"]");
        
        //test del costruttore con parametri
        Complex c2 = new Complex(8.9, -11.4);
        System.out.println("Lo stato del numero complesso ottenuto per copia vale");
        System.out.println("[Re: "+c2.getRe()+", Imm: "+c2.getImm()+"]");
        
        //test funzione modulo
        double modulo = c1.moduloComplex();
        System.out.println("Il modulo di c1 e:" + modulo);
        
        //test somma tra numeri complessi
        Complex cSomma;
        cSomma = c1.sommaComplex(c2);
        System.out.println("Lo stato di cSomma vale");
        System.out.println("[Re: "+cSomma.getRe()+", Imm: "+cSomma.getImm()+"]");
        
        //test prodotto tra numeri complessi
        Complex cProdotto;
        cProdotto = c1.prodottoComplex(c2);
        System.out.println("Lo stato di cProdotto vale");
        System.out.println("[Re: "+cProdotto.getRe()+", Imm: "+cProdotto.getImm()+"]");
        
        //test confronto
        System.out.println(c1.equals(compCopia));
        
        //test input
        Scanner input = new Scanner (System.in); 
        input.useLocale(Locale.US);
        Complex c3;
        c3=Complex.inputComplex(input);
        
        //test to string
        System.out.println("prova: " + c3.toString());  //chiamata esplicita
        System.out.println("prova: " + c3);  //chiamata implicita
        
        
    }
    
}
