/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package homework2;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author domenico
 */
public class ArrayComplex {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int DIM = 3;
        boolean continua = true;
        Position p = new Position();
        int scelta;
        Complex[] arrayVettori = new Complex[DIM];
        
        InsertComplexFromTerminal(arrayVettori);
        while (continua){
            PrintMenu();
            Scanner input = new Scanner (System.in);
            input.useLocale(Locale.US); 
            scelta = input.nextInt();
            switch(scelta) {
                case 1:
                    System.out.println("L'array di complessi è:");
                    PrintAll(arrayVettori);
                    break;
                case 2:
                    System.out.println("I moduli dei complessi sono");
                    PrintAllModules(arrayVettori);
                    break;
                case 3:
                    Complex c = Complex.inputComplex(input);
                    if(Search(arrayVettori, c, p)){
                        System.out.println("Numero complesso in posizione "+p.getPos());
                    } else {
                        System.out.println("Numero complesso non trovato");
                    }
                    break;
                case 4:
                    BubbleSort(arrayVettori);
                    System.out.println("Vettore ordinato");
                    break;
                case 5:
                    continua=false;
                    break;
            }
        }
    }
    
    public static void InsertComplexFromTerminal(Complex[] array){
        Scanner input = new Scanner (System.in); 
        input.useLocale(Locale.US); 
        for(int i=0; i<array.length; i++){
            Complex c = Complex.inputComplex(input);
            array[i]= new Complex(c);
        }
    }
    
    public static void PrintAll(Complex[] array){
        for(Complex c:array){
            //System.out.println(c.toString());
            System.out.println(c);
        }
    }
    
    //versione non ottimizzata del bubble sort
    public static void BubbleSort(Complex[] array){
        int j;
        Complex pivot;
        for(Complex element: array) {
            for(j=0;j<array.length-1;j++) {
                if(array[j].moduloComplex()>array[j+1].moduloComplex()) {
                    //swap
                    pivot=array[j];
                    array[j]=array[j+1];
                    array[j+1]= pivot;
                }
            }
        }
    }
    
    public static boolean Search(Complex[] array, Complex e, Position pos){
        boolean trovato = false;
        int indice=0;
        pos.setPos(-1);
        while(!trovato && indice<array.length){
            if(array[indice].equals(e)){
                trovato=true;
                pos.setPos(indice);
            } else {
                indice++;
            }
        }
        return trovato;
    }
    
    public static void PrintAllModules(Complex[] array){
        int i=0;
        for(Complex c:array){
            System.out.println("Modulo di num. complesso di pos "+i+": "+c.moduloComplex());
            i++;
        }
    }
    
    public static void PrintMenu(){
        System.out.println("******* Menu *******");
        System.out.println("1. Stampa array");
        System.out.println("2. Stampa i moduli di tutti i numeri complessi");
        System.out.println("3. Cerca numero complesso");
        System.out.println("4. Ordina array");
        System.out.println("5. Esci");
        System.out.println("********************");
    }
    
}
