/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercitazione;

import java.time.LocalDate;

/**
 *
 * @author domenico
 */
public class CartaID implements Expirable {
    String Titolare;
    Data scadenza;

    public CartaID(String Titolare, int gg, int mm, int aa) {
        this.scadenza = new Data(gg,mm,aa);
        this.Titolare = new String(Titolare);
    }
    
    @Override
    public boolean IsExpired() {
        LocalDate currentDate = LocalDate.now();
        int giorno = currentDate.getDayOfMonth();
        int mese = currentDate.getMonthValue();
        int anno = currentDate.getYear();
        
        Data oggi = new Data(giorno,mese,anno); 
        return oggi.IsAfter(scadenza); 
    }

    @Override
    public String toString() {
        return "CartaID{" + "Titolare=" + Titolare + ", scadenza=" + scadenza + '}';
    }
    
    
}
