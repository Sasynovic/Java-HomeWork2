/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercitazione;

import java.time.LocalDate;

/**
 *
 * @author domenico
 */
public class ProdottoAlimentare implements Expirable{
    
    String Descrizione;
    Data scadenza;

    public ProdottoAlimentare(String Descrizione, int gg, int mm, int aa) {
        this.Descrizione = new String(Descrizione);
        this.scadenza = new Data(gg,mm,aa);
    }
    
    @Override
    public boolean IsExpired() {
        LocalDate currentDate = LocalDate.now();
        int giorno = currentDate.getDayOfMonth();
        int mese = currentDate.getMonthValue();
        int anno = currentDate.getYear();
        
        Data oggi = new Data(giorno,mese,anno); 
        return oggi.IsAfter(scadenza); 
    }

    @Override
    public String toString() {
        return "ProdottoAlimentare{" + "Descrizione=" + Descrizione + ", scadenza=" + scadenza + '}';
    }
    
}
