/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package esercitazione;

/**
 *
 * @author domenico
 */
public class Esercitazione {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Expirable checklist[] = new Expirable[4];
        CartaID c1=new CartaID("Mario Rossi", 20,4,2028);
        CartaID c2=new CartaID("Giulia Bianchi", 3,9,2023);
        ProdottoAlimentare p1 = new ProdottoAlimentare("Pollo",20,6,2024);
        ProdottoAlimentare p2 = new ProdottoAlimentare("Orata",8,5,2024);
        checklist[0]=c1;
        checklist[1]=p1;
        checklist[2]=c2;
        checklist[3]=p2;
    
    
    for(Expirable e : checklist)
       System.out.println(e + "e' scaduto: " + e.IsExpired());
    
   }
}

