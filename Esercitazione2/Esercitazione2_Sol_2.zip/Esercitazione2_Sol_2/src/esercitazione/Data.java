/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercitazione;


/**
 *
 * @author domenico
 */
public class Data {
    
    private int giorno;
    private int mese;
    private int anno;

    public Data(int gg, int mm, int aa) {
        this.giorno = gg;
        this.mese = mm;
        this.anno = aa;
    }
    
    public boolean IsAfter(Data d){
        if (this.anno==d.anno) {
            if (this.mese>d.mese) return true;
                else return (this.giorno>d.giorno);
        }
        else return (this.anno>d.anno);
    }

    @Override
    public String toString() {
        return "Data{" + "giorno=" + giorno + ", mese=" + mese + ", anno=" + anno + '}';
    }
    
    
    
}
