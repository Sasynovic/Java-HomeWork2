/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercitazione;

import java.time.LocalDate;

/**
 *
 * @author domenico
 */
public class ProdottoAlimentare extends Expirable{
    
    String Descrizione;

    public ProdottoAlimentare(String Descrizione, int gg, int mm, int aa) {
        //super.scadenza = new Data(gg,mm,aa); //necessario se si omette il costruttore di classe astratta
        super(gg,mm,aa); //si deve togliere se si omette il costruttore di classe astratta
        this.Descrizione = new String(Descrizione);
        
    }
    
    @Override
    public String toString() {
        return "ProdottoAlimentare{" + "Descrizione=" + Descrizione + ", scadenza=" + scadenza + '}';
    }
    
}
