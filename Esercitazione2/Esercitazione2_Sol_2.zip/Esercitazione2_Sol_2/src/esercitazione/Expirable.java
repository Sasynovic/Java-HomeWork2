/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package esercitazione;

import java.time.LocalDate;

/**
 *
 * @author domenico
 */
public abstract class Expirable {
    
    protected Data scadenza;
    
    public Expirable(int gg, int mm, int aa){
        scadenza = new Data(gg,mm,aa);
        
    }
    
    public boolean IsExpired() {
        LocalDate currentDate = LocalDate.now();
        int giorno = currentDate.getDayOfMonth();
        int mese = currentDate.getMonthValue();
        int anno = currentDate.getYear();
        
        Data oggi = new Data(giorno,mese,anno); 
        return oggi.IsAfter(scadenza); 
    }
    
    
}
