/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package esercitazione;

import java.time.LocalDate;

/**
 *
 * @author domenico
 */
public class CartaID extends Expirable {
    String Titolare;

    public CartaID(String Titolare, int gg, int mm, int aa) {
        //super.scadenza = new Data(gg,mm,aa); //necessario se si omette il costruttore di classe astratta
        super(gg,mm,aa); //si deve togliere se si omette il costruttore di classe astratta
        this.Titolare = new String(Titolare);
    }
    

    @Override
    public String toString() {
        return "CartaID{" + "Titolare=" + Titolare + ", scadenza=" + scadenza + '}';
    }
    
    
}
